def hello():
    print('phase-e-valid')
    return 42
